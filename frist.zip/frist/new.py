import asyncio
import os
import discord
from dotenv import load_dotenv
from discord import Intents, Client, Message, VoiceChannel, VoiceClient
from discord.ext import commands
from discord import FFmpegPCMAudio
import random

# Load Discord bot token from environment variable
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

# Set up Discord bot
intents = Intents.default()
intents.message_content = True
intents.voice_states = True  # Enable VoiceState intent for voice channel tracking
bot = commands.Bot(command_prefix="!", intents=intents)

# Keep track of the voice client
voice_client = None


# Function to handle user joining a voice channel
@bot.event
async def on_voice_state_update(member, before, after):
    if member == bot.user:
        return

    if after.channel is not None:  # User joined a channel
        global voice_client
        if voice_client is None:
            try:
                voice_channel: VoiceChannel = after.channel
                voice_client = await voice_channel.connect()
            except discord.ClientException as e:
                print(f"Error joining voice channel: {e}")
    else:  # User left a channel
        if voice_client is not None and len(voice_client.channel.members) == 1:
            await voice_client.disconnect()
            voice_client = None

# async def PlayMusic(music_file):
#     music_source = FFmpegPCMAudio(music_file)
#     player = voice_client.play(music_source)

#     while player.is_playing():
#         await asyncio.sleep(1)


@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    if message.content.lower() == "hi":
        if voice_client is not None:  # Bot is already in a voice channel
            # Play a random audio file when user says "hi"
            i = random.randrange(1, 11)
            music_file = "hello.mp3"
            music_source = FFmpegPCMAudio(music_file)
            player = voice_client.play(music_source)

            while player.is_playing():
                await asyncio.sleep(1)
            # PlayMusic(music_file)

    elif message.content.lower() == "bye":
        if voice_client is not None:  # Bot is already in a voice channel
            # Play audio file when user says "bye"
            music_file = "bye.mp3"
            music_source = FFmpegPCMAudio(music_file)
            player = voice_client.play(music_source)

            while player.is_playing():
                await asyncio.sleep(1)

    elif message.content.lower() == "news":
        if voice_client is not None:
            # Play a random news audio file
            i = random.randrange(1, 11)
            music_file = f"{i}.mp3"
            music_source = FFmpegPCMAudio(music_file)
            player = voice_client.play(music_source)

            while player.is_playing():
                await asyncio.sleep(1)

    elif message.content.lower() == "how are you":
        if voice_client is not None:
            # Play an audio file responding to "how are you"
            music_file = "care.mp3"
            music_source = FFmpegPCMAudio(music_file)
            player = voice_client.play(music_source)

            while player.is_playing():
                await asyncio.sleep(1)

    elif message.content.lower() == "joke":
        if voice_client is not None:
            # Play an audio file with a joke
            music_file = "joke.mp3"
            music_source = FFmpegPCMAudio(music_file)
            player = voice_client.play(music_source)

            while player.is_playing():
                await asyncio.sleep(1)

    elif message.content.lower() == "about":
        if voice_client is not None:
            # Play an audio file providing information about the bot
            music_file = "help.mp3"
            music_source = FFmpegPCMAudio(music_file)
            player = voice_client.play(music_source)

            while player.is_playing():
                await asyncio.sleep(1)

    elif message.content.lower() == "stop":
        if voice_client is not None and voice_client.is_playing():
            # Stop the currently playing audio
            voice_client.stop()
            
    elif message.content.lower()  == "help":
      await message.channel.send(f"""
!stop: Stop the currently playing audio.
!hi: Receive a friendly response from the bot.
!bye: Say goodbye to the bot.
!news: Get random news about India.
!how are you: Engage in a caring conversation with the bot.
!joke: Listen to a joke from the bot.
!about: Get details about the bot.
""")
    else:
        await message.channel.send("enter the correct commands in the list")


# Run the bot
def main() -> None:
    bot.run(token=TOKEN)


if __name__ == "__main__":
    main()
