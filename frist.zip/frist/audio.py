from gtts import gTTS

# lang='en'
# for i in range(1,5):
#     text = input(f"entert the text for {i} number ")
#     audio = gTTS(text=text,lang=lang)
#     name = input("enter the file name")
#     audio.save(f'{name}.mp3')
    
    
    
text = input(f"entert the text for  number ")
lang = 'en'
audio = gTTS(text=text,lang=lang)
name = input("enter the file name")
audio.save(f'{name}.mp3')